# Ontology Lab × APQC 双工作区改造方案

> 版本 v0.1（评审稿）· 2026-10-15
> 目标：把现有 5 Tab 结构重组为「数据脊柱 + 流程工作台 + 本体资产库」，让 FDE 闭环（访谈 → 画流程 → 沉淀本体 → 覆盖度找 gap）在一个插件内完成。

---

## 0. 一页速览

**一句话**：工具不改名、不拆分，把 5 个平铺 Tab 重组为"流程工作台 + 本体资产库"两个工作区；实体只锚定业务域（L1/L2），流程才映射 L3-L5，两者用"参与关系"桥接——画完流程图，覆盖度自动更新。

### 现状 vs 目标对照

| 维度 | 现状 | 目标 |
|---|---|---|
| 导航 | 5 个平铺 Tab，工作流不连贯 | 两个工作区分组，gap → 访谈/画板一键跳转 |
| 实体映射 | 任何实体可挂任意 APQC 层级（"合同"被迫塞进某个子流程） | 实体只允许 L1/L2；流程类才允许 L3-L5，抽屉录入时强制分流 |
| 覆盖度 | 单一指标，L3 的"覆盖"靠人工把实体摆上去，失真 | 双指标：域覆盖（实体×L1/L2，人工）+ 流程覆盖（自动推导，只读） |
| 流程图 | 画布只存图形（节点带 APQC 编号，但无语义） | 双写：布局 + 语义（挂载 L3、参与实体+op、角色/规则/行为），画完即沉淀本体 |
| 访谈 | 无工具支撑，靠笔记 | 四问 checklist（角色？对象？规则？行为？），现场记录一键转本体关系 |
| 域词典 | `domain` 自由字符串，跨套件对不上 | 受控词表 = APQC L1/L2 + 别名，实体归一有依据 |
| CRUD 矩阵 | 无 | 实体 × 流程矩阵视图，FDE 交付物直接可用 |

### 不变的部分

- 套件导入/解析/重新导入流程、实体关系图交互、画布拖拽连线体验、现有 16 条 API——全部保留。
- 旧数据平滑兼容：违规存量映射只标记不删除，人工确认迁移。

---

## 1. 背景与设计原则

### 1.1 模型纠正（本次改造的出发点）

| 层 | 内容 | APQC 对应 | 建模方式 |
|---|---|---|---|
| 名词层 | 实体 / 聚合根 / 规则等业务对象 | L1（领域类别）/ L2（流程组） | `domain` 字段锚定，归属唯一、跨域引用 |
| 动词层 | FLOW / ACTIVITY | L3（流程）/ L4（活动）/ L5（任务） | `FrameMapping` 映射，一对一 |
| 桥 | 参与关系（谁对什么对象做什么） | — | 关系 + op（CRUD），多对多，**推导覆盖度** |

核心纠正：**实体不再映射到 L3-L5**。L3+ 的覆盖度由"流程挂载 + 参与关系"自动推导，不再人工放置。

### 1.2 改造原则

1. **不重写**：现有 5 Tab 与目标结构映射很近，只做导航重组 + 语义升级 + 3 处新增。
2. **不拆插件**：拆的是工作区，不是产品。APQC 树数据与域词典是共享脊柱。
3. **每期可用**：P1/P2/P3 各期结束时工具完整可用，不做长周期分支。
4. **向后兼容**：旧 `annotations.json`、旧流程图数据可平滑迁移，不破坏现有套件。

---

## 2. 目标总体架构

```
一个插件（dsh-ontology）
├─ 数据脊柱（共享）
│   ├─ 域词典：受控词表 = APQC L1/L2 + 别名/同义词（实体 domain 归一依据）
│   └─ 框架注册表：FrameworkDefinition 插拔（APQC PCF 为首个内置框架）
├─ 工作区 1 · 流程工作台
│   ├─ APQC 地图（现 framework.html 升级）
│   ├─ 流程画板（现 flowchart.html 语义化）
│   └─ 访谈清单（新增）
├─ 工作区 2 · 本体资产库
│   ├─ 本体图谱（现 ontology.html 增强）
│   ├─ 套件管理（现 suites.html，基本不动）
│   └─ 覆盖度（现 coverage.html 拆双指标）
└─ 桥
    ├─ ACTIVITY_OPERATES_OBJECT 关系（op: create/read/update/delete/approve）
    └─ 语义投影：画板/访谈产出 → suite.relations 派生关系 → 覆盖度自动更新
```

### 导航结构（layout.html 改造）

```
现：[本体] [本体管理] [APQC] [流程图] [覆盖度]        ← 平铺
新：▎流程工作台              ▎本体资产库
    [APQC 地图]              [本体图谱]
    [流程画板]               [套件管理]
    [访谈清单]               [覆盖度]
```

顶部套件选择条保留：当前 suite 上下文跨工作区共享，即"桥实时共享"的载体。

### FDE 使用旅程（改造后的工作方式）

**场景 1 · 进场准备（出发前）**
打开「APQC 地图」→ 按客户行业扫 L1/L2：域覆盖度低的区域就是明天访谈要重点问的。导出该 L2 下的 L3/L4 清单作为访谈提纲。

**场景 2 · 客户访谈中（现场）**
打开「访谈清单」→ 选定 L2 范围 → 陪客户逐流程过四问（这个活动谁做？动哪些单据？有什么规矩？系统里怎么处理？）。现场只做记录，gap 直接标"客户未提"。
客户白板上画了流程？回酒店在「流程画板」10 分钟复现：挂到 L3，拖 L4 活动，给每个活动补上对象和 op。

**场景 3 · 沉淀（项目结束后）**
画板保存时语义投影已自动生成参与关系 → 「覆盖度」流程区自动点亮；「本体图谱」里新实体已按域词典归一 → 跨套件可检索复用；「CRUD 矩阵」直接进交付文档。
下一个同类客户进场时，场景 1 的地图上你的覆盖度已经变厚——这就是本体资产的复利。

---

## 3. 数据结构变更（shared-types.ts）

### 3.1 域词典（新增）

```ts
export interface DomainDictEntry {
  code: string          // APQC L1/L2 编号，如 "4.0" / "4.3"
  label: string         // 中文名，如 "交付实物产品与服务"
  aliases?: string[]    // 客户侧叫法，如 ["生产运营", "制造管理"]
  level: 'L1' | 'L2'
  parentCode?: string   // L2 指向其 L1
}

export interface DomainDictionary {
  frameworkId: string          // 来源框架，如 'apqc-pcf'
  entries: DomainDictEntry[]
  updatedAt: number
}
```

- P1 从 `builtin-frameworks.ts` 的 APQC L1/L2 自动生成（只读）；P2 起支持别名编辑。
- 存储位置：`datastorage/<ds>/dictionary.json`（与套件数据同级，不混入 annotations）。

### 3.2 FrameMapping 按 kind 分流（校验层改造，存储结构不变）

`FrameMapping` 结构不动，**新增按实体 kind 的校验规则**（UI 录入限制 + 覆盖度计算分流双重执行）：

```ts
// 允许映射到 L1/L2 的 kind（名词层）
const DOMAIN_KINDS = ['AGGREGATE_ROOT', 'ENTITY', 'DATA_DICTIONARY', 'RULE', 'ACTOR', 'ROLE', 'REPORT']
// 允许映射到 L3-L5 的 kind（动词层）
const PROCESS_KINDS = ['FLOW', 'ACTIVITY']
// BEHAVIOR / UI_MENU / UI_SCREEN 等暂不参与 APQC 映射
```

- 迁移：现有 `entityFrameMapping` 中不符合规则的映射**不删除**，标记 `violated: true` 并在 UI 提示"待迁移动作"（挪到对应层或清除）。

### 3.3 参与关系（桥，新增 RelationType）

```ts
export type RelationType =
  | ... // 现有类型全部保留
  | 'ACTIVITY_OPERATES_OBJECT'   // 新增：活动 → 实体

// 关系 properties 约定
{
  op: 'create' | 'read' | 'update' | 'delete' | 'approve',
  derivedFrom?: `flow:${flowId}` | `interview:${interviewId}`  // 派生来源，可追溯
}
```

- 保留 `FLOW_BUSINESS_OBJECT` 作为流程级粗粒度关系（兼容现有解析产物）。
- `ACTIVITY_OPERATES_OBJECT` 由流程画板 / 访谈清单产生，是 **CRUD 矩阵与流程覆盖度的数据源**。
- ACTIVITY 实体的 `properties` 增加可选字段：`{ role?: string, guardRules?: string[], behaviorRefs?: string[] }`（Action 枢纽的角色/守卫/行为引用）。

### 3.4 流程图文档 v2（语义化双写）

现状：`POST /api/flowcharts` 保存 `{ id, name, nodes: [{id,type,code,label,x,y}], edges: [{id,source,target}] }`——节点已带 APQC `code`（拖拽产生），但无流程挂载、无参与关系。

```ts
export interface FlowDoc {
  id: string
  name: string
  suiteId: string
  apqcCode?: string          // 新增：整张流程图挂载的 L3 节点
  nodes: FlowNode[]          // 现有结构保留 {id,type,code?,label,x,y}
  edges: FlowEdge[]          // 现有结构保留，可加 label
  semantics?: {              // 新增：语义层（P2）
    activities: Record<string, {   // key = 节点 id
      roleRef?: string
      guardRules?: string[]
      behaviorRefs?: string[]
    }>
    participations: {        // 生成 ACTIVITY_OPERATES_OBJECT
      nodeId: string
      entityId: string
      op: 'create' | 'read' | 'update' | 'delete' | 'approve'
    }[]
  }
}
```

**语义投影**：保存 FlowDoc 时，server 根据 `semantics` 生成/更新 suite.relations 中的派生关系（带 `derivedFrom: flow:<id>` 标记），删除流程图时同步清理其派生关系。布局数据（x/y）只留在 FlowDoc，不污染本体。

### 3.5 访谈记录（新增存储）

```ts
export interface InterviewRecord {
  id: string
  suiteId: string
  apqcCode: string           // 被访谈的 L3/L4 节点
  answers: {
    hasRole?: { value: boolean; roleRef?: string; note?: string }
    hasObject?: { value: boolean; entityId?: string; op?: string; note?: string }
    hasRule?: { value: boolean; ruleRef?: string; note?: string }
    hasBehavior?: { value: boolean; behaviorRef?: string; note?: string }
  }
  createdAt: number
  updatedAt: number
}
```

- 存储：`datastorage/<ds>/interviews/<suiteId>.json`（独立文件，避免与重新导入冲突）。
- 访谈记录可直接"转为参与关系"（带 `derivedFrom: interview:<id>`）。

---

## 4. 覆盖度算法变更（datastore.ts）

现有 `computeCoverage` 拆为两个函数，页面分两个指标区展示：

### 4.1 域覆盖度（名词轴，人工锚定）

```
输入：suite.annotations.entityFrameMapping，仅统计 kind ∈ DOMAIN_KINDS 的映射
目标层级：仅 L1/L2（L3+ 节点不再出现在实体覆盖树中）
计算：沿用现有 collectAncestorCodes + rollup 逻辑，范围截断到 L2
输出：DomainCoverageMatrix { tree(仅L1/L2), cells, leafStats }
```

### 4.2 流程覆盖度（动词轴，自动推导）

```
输入：suite 内全部 FlowDoc + annotations（流程类映射）+ ACTIVITY_OPERATES_OBJECT 关系
对每个 L3 节点 code：
  covered ⇔ 存在 FlowDoc.apqcCode === code 且其 participations 非空
  partial ⇔ 存在挂载 FlowDoc 但无任何参与关系
  gap/unset ⇔ 无挂载
对每个 L4 节点 code（对应 ACTIVITY 映射或画板活动节点）：
  covered ⇔ 有 op 且有 role（四问中两核心项满足）
  partial ⇔ 仅满足其一
rollup：复用 calcRollupStatus，L3 状态由其子树/自身推导
输出：ProcessCoverageMatrix { tree(L3-L5), cells, gapList }
```

汇总条数字含义随分流更新（域覆盖看实体、流程覆盖看流程）。

---

## 5. API 变更清单（server.ts）

现有 16 条路由全部保留。新增：

| Method | Path | 用途 | 期次 |
|---|---|---|---|
| GET | `/api/dictionary` | 域词典（内置 L1/L2 + 别名） | P1 |
| POST | `/api/dictionary/aliases` | 别名编辑 | P2 |
| GET | `/api/suites/:suite/crud-matrix` | CRUD 矩阵（实体 × 流程/活动聚合） | P3 |
| GET/POST/DELETE | `/api/suites/:suite/interviews(/:id)` | 访谈记录 CRUD | P3 |
| POST | `/api/flowcharts`（扩展） | 保存时执行语义投影（P2 起生效） | P2 |
| GET | `/api/suites/:suite/derived-relations` | 查看派生关系及其来源 | P2 |

---

## 6. 页面改造详单

### 改造收益总览

| 页面 | 现状问题 | 改造收益 |
|---|---|---|
| layout.html（外壳） | 实体可挂任意层级 → "合同塞进子流程"的别扭 | 录入即分流，模型错误在入口处被拦截 |
| framework.html | 纯浏览，看完框架还得去别处干活 | 变作战地图：每个 gap 节点都是工作入口，一键跳访谈/画板 |
| flowchart.html | 画的图只存图形，本体"看不见"这张图 | 画完即沉淀：参与关系、覆盖度、CRUD 矩阵自动产生 |
| interview.html（新） | 访谈靠笔记，成果进不了工具 | 四问记录一键转本体关系，gap 即访谈重点 |
| ontology.html | 实体详情只有"挂了哪个 APQC" | 能反查"被哪些流程怎么用"，CRUD 矩阵可直接进交付物 |
| coverage.html | L3 覆盖靠人工摆放，数字失真 | 双指标各答一问：本体缺哪个域？哪些流程还没数字化？ |
| suites.html | domain 自由字符串 | 域对齐指示，跨套件归一有抓手 |

### 6.1 layout.html（外壳）

- 导航改双工作区分组（见 §2）。
- **抽屉改造**：APQC 编号输入按当前实体 kind 限制搜索范围——实体类只返回 L1/L2 建议，流程类只返回 L3-L5；违规输入即时提示。增加"域归属"展示（词典 label + 别名匹配）。

```
┌─ 抽屉（实体类）──────────────┐
│ 实体信息                       │
│ 域归属：4.3 交付实物产品与服务    │  ← 新增，来自词典
│ APQC 编号：[4.3____]           │  ← 仅 L1/L2 可选，L3+ 灰置
│   ⚠ 该实体类型仅允许映射到 L1/L2 │  ← 分流校验
│ 覆盖状态 / 备注（不变）          │
└──────────────────────────────┘
```

### 6.2 framework.html → APQC 地图（流程工作台首页）

左栏树浏览不变。右栏详情从"静态信息"升级为"工作台入口"：

```
┌─ 节点详情（按层级变化）─────────────────────┐
│ 4.3 交付实物产品与服务 (L2)                  │
│ 定义：…                                    │
│ ── 本域实体（跨当前 suite）──                │
│   合同(AGGREGATE_ROOT) 订单(ENTITY) +3      │
│   域覆盖：▓▓▓░░ 6/12                        │
│ ── 挂载流程 ──                              │
│   ✅ 4.3.1 订单履行  [去画板] [去访谈]        │
│   ⚠️ 4.3.2 库存管理  流程已挂、无参与关系      │
│   ⬜ 4.3.3 售后支持  未覆盖 → gap            │
└──────────────────────────────────────────┘
```

- L1/L2 节点：域实体清单 + 域覆盖进度。
- L3 节点：挂载的 FLOW 列表 + 流程覆盖状态 + `[去画板]` `[去访谈]` 跳转按钮。
- L4 节点：Action 四问状态徽标（角色/对象/规则/行为）。

### 6.3 flowchart.html → 流程画板（语义化）

保留画布交互。三处升级：

```
┌─ 画板工具栏 ────────────────────────────────┐
│ 流程名：[订单履行流程]  挂载APQC：[4.3.1 ▾]    │ ← 新增 L3 挂载选择
│ [💾 保存] [🆕 新建] [🖼️ PNG] [⇄ PlantUML]    │ ← PlantUML 为 P3 可选项
├─ 画布：拖 APQC L4 生成活动节点（现状保留）─────┤
│   ┌──────────┐    ┌──────────┐              │
│   │ 审核订单   │───→│ 创建发货单 │              │
│   │ ⚑角色 ✓   │    │ ⚑角色 ✗   │              │ ← 节点角标显示四问完成度
│   │ ◇对象 ✓   │    │ ◇对象 ✗   │              │
│   └──────────┘    └──────────┘              │
├─ 节点属性面板（点选节点，右侧）────────────────┤
│ 活动：审核订单 (4.3.1.1)                      │
│ 角色：[订单主管 ▾]        ← ACTIVITY_ROLE     │
│ 操作对象：                                   │
│   订单  [update ▾]        ← 参与关系+op       │
│   [+ 添加对象]                               │
│ 守卫规则：[R-信用检查 ✓] [+ 添加]              │
│ 调用行为：[B-扣减库存 ✓] [+ 添加]              │
└──────────────────────────────────────────┘
```

- 保存时双写：布局存 FlowDoc，语义投影生成 `ACTIVITY_OPERATES_OBJECT` 等派生关系。
- 完成后覆盖度页 L3 自动点亮（无需手工标注）。

### 6.4 interview.html → 访谈清单（新增页）

```
┌─ 访谈模式 ──────────────────────────────────┐
│ 范围：[4.3 交付实物产品与服务 ▾]  进度 3/9     │
├──────────────────────────────────────────┤
│ ▸ 4.3.1 订单履行          ✅ 已完成          │
│ ▾ 4.3.2 库存管理           🔄 进行中          │
│   ┌ 四问 checklist ─────────────────────┐   │
│   │ 角色？  [✓] 库管员                    │   │
│   │ 对象？  [✓] 库存记录 [update ▾]       │   │
│   │ 规则？  [✗] 客户未提（记为 gap）        │   │
│   │ 行为？  [✓] B-库存盘点                │   │
│   │ 备注：[________________]              │   │
│   │ [转为参与关系] [去画板补画]             │   │
│   └─────────────────────────────────────┘   │
│ ▸ 4.3.3 售后支持           ⬜ 未开始          │
└──────────────────────────────────────────┘
```

- 数据源：APQC 树 + 现有覆盖状态（gap 项即访谈重点）。
- 产出：InterviewRecord → 一键转参与关系 / 跳画板。

### 6.5 ontology.html → 本体图谱

- 图形视图保留；右侧实体详情新增"**参与流程**"反查区（该实体被哪些活动以什么 op 引用，点击跳画板）。
- 新增视图切换：`[图形] [CRUD 矩阵]`：

```
┌─ CRUD 矩阵（实体 × 流程）────────────────────┐
│          │ 4.3.1 订单履行 │ 4.3.2 库存管理 │   │
│ 订单      │  C R U        │  R            │   │
│ 库存记录   │  R U          │  C R U D      │   │
│ 发货单    │  C R          │  —            │   │
└──────────────────────────────────────────┘
```

### 6.6 coverage.html → 双指标

```
┌─ 域覆盖度（实体 × L1/L2 · 人工锚定）───────────┐
│ 4.0 交付实物产品与服务  ▓▓▓▓░ 8/12  partial   │
│ 5.0 交付服务              ▓▓░░░ 3/9   gap…   │
├─ 流程覆盖度（L3-L5 · 由流程与参与关系自动推导）──┤
│ 4.3.1 订单履行   ✅ covered（挂载+5 参与）      │
│ 4.3.2 库存管理   ⚠️ partial（挂载、无参与）      │
│ 4.3.3 售后支持   ⬜ 未挂载 → gap               │
└──────────────────────────────────────────┘
```

### 6.7 suites.html

列表增加"域对齐"列：套件内实体 domain 能否全部映射到词典（未对齐数量红点提示）。

### 6.8 域词典入口

P1 在覆盖度页内嵌只读词典面板（不单独开 Tab）；P2 起提供别名编辑对话框。

---

## 7. 工程与构建变更

| 项 | 变更 |
|---|---|
| `src/ui/layout.html` | 导航分组；新增 `pages/interview.html` 等 include |
| `src/ui/pages/` | 新增 interview.html；其余 4 页就地改造 |
| `src/ui/scripts/` | 对应新增 interview.js、扩展 framework.js / flowchart.js / coverage.js / ontology.js |
| `src/ui/css/` | 新增 interview.css；base.css 增加分组导航样式 |
| `scripts/build-ui.mjs` | include 条目同步（HTML/CSS/JS 三处），缺失即抛错的机制不变 |
| `package.json` | dev 的 chokidar 监听 `src/ui/**/*` 已覆盖新文件，无需改 |
| **重启提醒** | server 启动时 readFileSync 缓存 HTML——**改 UI 后必须重启 server 才生效** |
| 回归测试 | 沿用临时 serve.mjs（repo 外）+ `dist/server.js` + `startServer(17399)`；注意图例 chip 重建 innerHTML、实体 domain 含套件领域名等旧陷阱 |

---

## 8. 分期实施计划

### P1 · 脊柱分流（覆盖度变诚实）

| # | 任务 | 涉及文件 |
|---|---|---|
| 1 | DOMAIN_KINDS / PROCESS_KINDS 常量 + 抽屉按 kind 限层校验 | shared-types.ts, ui/scripts/shared.js, layout.html(抽屉) |
| 2 | computeCoverage 拆分域覆盖（限实体 + 截断 L2） | datastore.ts, server.ts |
| 3 | 覆盖度页双指标布局（流程区先显示"待 P2"占位） | coverage.html/js, coverage.css |
| 4 | 域词典只读生成 + 覆盖度页内嵌面板 | builtin-frameworks.ts(或新 dictionary.ts), server.ts |
| 5 | 迁移提示：违规映射标 `violated` 并在抽屉提示 | datastore.ts, ui/scripts |

**验收**：给实体输入 L3 编号被拒绝；旧 annotations 不损坏（回归通过）；覆盖度页出现两个指标区；违规存量映射有迁移提示。

### P2 · 画板语义化（画完即沉淀）

| # | 任务 | 涉及文件 |
|---|---|---|
| 1 | FlowDoc v2（apqcCode + semantics）存储与兼容旧数据 | datastore.ts / flowchart 存储 |
| 2 | 画板挂载 L3 选择器 + 节点属性面板（角色/对象+op/规则/行为） | flowchart.html/js |
| 3 | 语义投影：保存时生成派生关系，删除时清理 | server.ts, datastore.ts |
| 4 | 流程覆盖度推导上线，替换 P2 占位 | datastore.ts |
| 5 | ACTIVITY_OPERATES_OBJECT 入 RelationType 与解析器 | shared-types.ts, ontology-parser.ts |

**验收**：画一张带参与的流程图并挂载 L3 → 覆盖度流程区该 L3 变 covered；删除流程图后状态回退、派生关系无残留。

### P3 · 访谈闭环与 CRUD 矩阵

| # | 任务 | 涉及文件 |
|---|---|---|
| 1 | 访谈清单页（四问 checklist + 范围选择 + 进度） | interview.html/js/css, server.ts |
| 2 | 访谈记录转参与关系（带 derivedFrom） | server.ts, datastore.ts |
| 3 | CRUD 矩阵 API + 图谱页矩阵视图 | server.ts, ontology.html/js |
| 4 | APQC 地图页节点详情升级（实体清单/挂载流程/四问徽标/跳转） | framework.html/js |
| 5 | 实体详情"参与流程"反查 | ontology.html/js |

**验收**：从访谈记录一键生成参与关系并点亮覆盖度；CRUD 矩阵数据与画板/访谈产出一致；APQC 地图可从任意 gap 节点跳访谈/画板。

---

## 9. 风险与开放问题（评审时定）

| # | 问题 | 建议默认值 |
|---|---|---|
| 1 | op 词汇表起步范围？ | create / read / update / delete / approve，其余走 note |
| 2 | 访谈记录存哪？ | 独立 `interviews/<suiteId>.json`，不进 annotations |
| 3 | PlantUML 双向转换期次？ | P3 之后可选（文本 DSL 与画布互转），不阻塞主线 |
| 4 | 域词典允许客户化新增域吗？ | P1 只读；P2 起支持别名；新增自定义域放最后评估 |
| 5 | 旧存量实体→L3 映射迁移？ | 不自动迁移，标 `violated` 人工确认（抽屉内一键挪层/清除） |
| 6 | BEHAVIOR/UI_MENU 等是否参与 APQC？ | 暂不参与，留 `CUSTOM` 关系表达 |

---

## 10. 评审确认清单

评审时逐项勾选，回复序号+结论即可（如"1 同意，3 改到 P2"）：

- [ ] **Q1** op 词汇表：create / read / update / delete / approve 起步？
- [ ] **Q2** 访谈记录独立文件存储（不进 annotations）？
- [ ] **Q3** PlantUML 双向转换放 P3 之后可选？
- [ ] **Q4** 域词典 P1 只读、P2 起支持别名？
- [ ] **Q5** 旧存量实体→L3 映射不自动迁移，人工确认？
- [ ] **Q6** 分期顺序 P1 脊柱分流 → P2 画板语义化 → P3 访谈闭环？
- [ ] **Q7** 导航分组命名：「流程工作台 / 本体资产库」是否合适？
- [ ] **Q8** 流程画板 op 下拉与访谈 checklist 的四问口径已对齐（角色/对象/规则/行为），无需另设？

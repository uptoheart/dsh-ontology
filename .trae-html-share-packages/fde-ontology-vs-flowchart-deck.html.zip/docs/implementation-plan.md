# Ontology Lab 实现方案

> 版本 v1.0 · 2026-10 · dsh-ontology 插件

---

## 一、目标

在 DeepSeek Harness 插件体系内，提供一个**本地本体建模工作台**：

1. **Ontology 库** — 从 YAML/JSON 源文件解析实体与关系，以套件（suite）为单位持久化到本地 datastorage
2. **APQC 框架** — 内置官方 APQC Process Classification Framework v7.4 跨行业版（5 层 13 Domain / 71 L2 / 193 L3），作为"标准业务骨架"
3. **覆盖度标注** — 将 Ontology 实体映射到 APQC 节点，标记覆盖状态（已覆盖 / 部分 / 缺口 / 未标注），计算层级聚合覆盖矩阵
4. **可视化面板** — 单文件 SPA（iframe 嵌入 cordis 中心面板），零外部依赖，支持套件列表、覆盖度矩阵、框架树浏览、实体筛选与标注抽屉

核心原则：**不引入图数据库**（先用 SQLite/JSON 文件，后续可平滑迁移），**不依赖后端 Java 服务**（插件内嵌 HTTP server 自足），**保持 API 向后兼容**。

---

## 二、架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                        DeepSeek Harness                         │
│                                                                 │
│  cordis 插件运行时  ───────────►  dsh-ontology/client.js        │
│                                    │                            │
│  左侧 sidebar 注入  "Ontology" 按钮 │  discoverServer() 探测端口  │
│                                    ▼                            │
│  中心面板 iframe  ◄─────────  http://127.0.0.1:17320/           │
│                                    │                            │
└────────────────────────────────────┼────────────────────────────┘
                                     │
                        Node.js 内嵌 HTTP Server
                        (server.ts · 17320 ~ 17329 自动重试)
                                     │
             ┌───────────────────────┼───────────────────────┐
             ▼                       ▼                       ▼
   ontology-parser.ts          datastore.ts           apqc-pcf.ts
   (YAML → 实体/关系)          (SQLite/JSON IO)       (框架树数据)
             │                       │                       │
             └───────────┬───────────┘                       │
                         ▼                                   ▼
                   builtin-frameworks.ts              shared-types.ts
                   (框架工具 + 覆盖度计算)             (全部类型定义)
                                                         │
                                                         ▼
                                                  server.ts 路由层
                                                  /api/suites
                                                  /api/coverage
                                                  /api/frameworks
                                                  /api/annotations
                                                         │
                                                         ▼
                                                  dist/ui.html
                                          (src/ui/ 拆分源码组装产物)
```

### 数据流

```
datasource/YAML ──importFromDatasource()──► datastorage/JSON
                                                │
                                                ▼
                                          实体 / 关系 / 套件元数据
                                                │
                  ┌─────────────────────────────┤
                  ▼                             ▼
          server.ts GET /api/suites      server.ts GET /api/coverage
                                                │
                                                ▼
                                    computeCoverage() 递归聚合
                                    逐节点 status + 叶子 rollup
                                                │
                                                ▼
                                         CoverageMatrix 返回
                                         (树 + 层级矩阵 + 叶子统计)
```

### 存储分层（关键设计决策）

| 层 | 路径 | 内容 | 可写 |
|----|------|------|------|
| **datasource** | `src/datasource/Ontology/*/` | 原始 YAML（m1 模型到 m7 模型）+ 需求文档 | ❌ 只读 |
| **datastorage** | `src/datastorage/ontologies/{suiteId}/` | 解析后的 entities.json / relations.json / meta.json / annotations.json | ✅ 插件读写 |
| **框架数据** | `src/frameworks/apqc-pcf.ts` | TypeScript 常量，内置 APQC v7.4 完整层级 | ❌ 只读 |

**为什么分 datasource 和 datastorage 两层？**
- datasource 是**真相源**（source of truth），由大模型/人工维护 YAML
- datastorage 是**派生缓存 + 标注层**，包含解析结果和人工标注（APQC 编号、覆盖状态）
- 重新 import 时从 datasource 重新解析，但**保留 annotations.json**（标注不丢）

---

## 三、APQC 框架设计

### 编号体系

APQC v7.4 跨行业版采用 `{L1}.{L2}.{L3}.{L4}.{L5}` 分层编号：

```
L1  13  Domain  (战略、产品、财务、HR、IT、运营、供应链、客服、市场、开发、行政...)
L2  71  Process Group
L3  193 Process
L4  Activity   (示例中选部分节点，完整官方数据 ~800+)
L5  Task       (示例中选部分节点)
```

### 类型结构

```typescript
// shared-types.ts
interface FrameworkNode {
  code: string                    // 如 "9.3.1"
  name: string                    // 英文名 "Perform Account Reconciliation"
  label: string                   // 中文名 "执行账户对账"
  levelId: 1 | 2 | 3 | 4 | 5
  pcfId?: string                  // 官方 PCF 编号
  definition?: string
  children?: FrameworkNode[]      // 递归嵌套
}

// 框架整体
interface FrameworkDefinition {
  frameworkId: string             // "apqc-process"
  name: string
  version: string                 // "7.4"
  domains: FrameworkNode[]        // 13 个 L1
}
```

### APQC 编号 ↔ Ontology 编号推导规则

```
APQC: 9.3.1          →  Ontology: ONT.B.9.3.1
       ↑ ↑ ↑                  ↑ ↑ ↑ ↑ ↑
       L1 L2 L3               前缀 层级 编号
```

- 前缀 `ONT.B.` 代表 "Business Ontology"
- 层级映射：APQC L1 → Ontology Level 1，APQC L2 → Ontology Level 2
- 反向推导也支持：`deriveOntologyCode('9.3.1')` → `'ONT.B.9.3.1'`

### 框架工具函数（builtin-frameworks.ts）

| 函数 | 作用 |
|------|------|
| `getBuiltinFramework('apqc-process')` | 获取完整框架树 |
| `flattenFramework(nodes)` | 递归展开为扁平数组 |
| `collectLeafNodes(nodes)` | 收集所有 L3/L4/L5 叶子 |
| `findNodeByCode(nodes, code)` | 按编号查找节点 |
| `countNodesByLevel(nodes)` | `{1: 13, 2: 71, 3: 193, 4: N, 5: N}` |
| `deriveOntologyCode(apqcCode)` | APQC → Ontology 编号 |
| `deriveApqcCode(ontologyCode)` | Ontology → APQC 编号 |
| `getFrameworkStats(fw)` | 统计摘要 |

---

## 四、覆盖度计算引擎

### 核心数据结构

```typescript
// 每个框架节点的覆盖状态
interface CoverageNodeInfo {
  code: string
  name: string
  levelId: number
  entityCount: number             // 直接/间接关联的实体总数
  entities: string[]              // 实体 ID 列表（截断至 50）
  childStatuses: Record<string, CoverageStatus>
  status: CoverageStatus          // 聚合后状态
  // 叶子汇总（仅 L1/L2/L3 有）
  leafTotal?: number
  leafCovered?: number
  leafPartial?: number
  leafGap?: number
  leafUnset?: number
  children?: CoverageNodeInfo[]
}

type CoverageStatus = 'covered' | 'partial' | 'gap' | 'unset'

// 完整覆盖度返回
interface CoverageMatrix {
  frameworkId: string             // "apqc-process"
  suiteId: string
  computedAt: number
  totalEntities: number           // 该套件实体总数
  leafTotal: number               // 框架叶子总数
  leafCovered: number             // 至少有一个 covered 子节点
  leafPartial: number
  leafGap: number
  leafUnset: number
  tree: CoverageNodeInfo[]        // 完整覆盖树（对应框架树结构）
  cells: CoverageCell[]           // Domain × Level 矩阵（可选）
}
```

### 递归聚合算法（computeCoverage）

```
输入：FrameworkDefinition（框架树） + SuiteData（实体+关系+annotations）
输出：CoverageMatrix

1. 遍历框架树每个节点
   ├─ 节点 code 匹配 annotations.entityFrameMapping
   │   → 直接关联的实体
   │
2. 自底向上递归 rollup
   ├─ 叶子节点（无 children）
   │   status = 该节点实体的 coverageMarks 聚合
   │
   └─ 非叶子节点
       ├─ 汇总所有 leaf* 字段（covered + partial + gap + unset）
       ├─ 所有子节点都 covered → status = covered
       ├─ 有 covered 有 unset 混合 → status = partial
       ├─ 只有 gap → status = gap
       └─ 全 unset → status = unset
```

### 标注数据结构（annotations.json）

```jsonc
{
  "entityFrameMapping": {
    "<entityId>": {
      "frameworkId": "apqc-process",
      "apqcCode": "9.3.1",
      "note": "该实体属于账户对账",
      "mappedAt": "2026-10-15T10:30:00Z"
    }
  },
  "coverageMarks": {
    "<entityId>": {
      "status": "covered | partial | gap | unset",
      "markedAt": "2026-10-15T10:30:00Z"
    }
  }
}
```

- **entityFrameMapping** — 实体 → 框架节点的映射（可空，实体未挂载到任何 APQC 节点）
- **coverageMarks** — 覆盖状态标记（可独立于 mapping 存在，表示"这个实体我们知道但还没找到对应流程"）

---

## 五、后端 API 列表

基础 URL：`http://127.0.0.1:17320`（cordis 插件内嵌 server，端口 17320~17329 自动重试）

### 套件管理

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/suites` | 列出所有已导入套件（meta 信息） |
| GET | `/api/suites/{id}` | 获取单个套件详情（含 entities、relations、annotations） |
| POST | `/api/suites/import` | 从 datasource 重新解析并导入 |
| GET | `/api/datasource/suites` | 扫描 datasource 目录下有哪些可导入的套件（未解析） |

### 实体 & 关系

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/suites/{id}/entities` | 列出实体，支持 `?keyword=xxx` 过滤 |
| GET | `/api/suites/{id}/graph` | 返回 D3-force 图数据 `{nodes, edges}` |

### 标注

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/suites/{id}/annotations` | 保存标注（整体提交，合并到 annotations.json） |

### 框架

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/frameworks` | 列出所有可用框架 |
| GET | `/api/frameworks/apqc-process` | 获取完整 APQC 框架树（纯结构，不带覆盖数据） |

### 覆盖度

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/coverage?suite=xxx` | 计算并返回 CoverageMatrix（完整覆盖树 + 叶子统计） |

### 辅助

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/ontology-code/derive?apqc=9.3.1` | APQC → ONT.B.9.3.1 |

### 统一响应格式

```jsonc
{ "success": true, "data": { ... } }          // 成功
{ "success": false, "message": "错误描述" }    // 失败
```

### CORS

server 始终设置 `Access-Control-Allow-Origin` = 请求的 Origin（或 `*`），允许 iframe 跨域 fetch。

---

## 六、前端 SPA 设计

### 技术选型

- **多文件源码 + 构建时组装**：源码在 `src/ui/` 下按 Tab 拆分（`layout.html` + `css/` + `pages/` + `scripts/`），`scripts/build-ui.mjs` 通过 `@include` 标记递归组装为单文件 `dist/ui.html`。不引入 Vue/React/Vite
- 零外部依赖，组装后的 `dist/ui.html` 直接被 `server.ts` 的 `sendHtml` 返回
- build 流程：`tsc` 编译 server/client → `wrap-client.mjs` → `build-ui.mjs` 组装 dist/ui.html → 启动

**为什么不选框架？** cordis 插件环境下，server.ts 要 `readFileSync('ui.html')` 返回给 iframe。引入构建工具后 bundle 产物路径、注入时机、iframe 内 React mounting 都会变复杂。单文件 SPA 虽然代码量大，但好处是：
1. server 侧零配置，`readFileSync` 直接返回
2. 热更新友好（改 ui.html 刷新 iframe 即可）
3. cordis 正式 panel 模式下，iframe src 直接指向 serverBaseUrl，同源 fetch 无问题

**为什么源码要按 Tab 拆分？** 单文件 1800+ 行难维护，且多页面无法并行修改。拆分后每个 Tab 的 HTML/CSS/JS 独立成文件，可同时修改不同页面；构建时通过 `@include` 标记组装回单文件，server 侧与运行时行为完全不变。include 标记两种形式：
- HTML 片段：`<!-- @include: pages/suites.html -->`
- CSS/JS 片段：块注释 `/* @include: css/base.css */`

### 4 个 Tab 面板

```
┌───────────────────────────────────────────────────────┐
│  Ontology Lab  │  v1.0                                │
│  选择套件: reference-example     ↓    [🔄 刷新] [📦 重新导入]   │
├──────────┬──────────┬──────────┬──────────────────────┤
│ 套件列表 │ 覆盖度   │ APQC框架 │ 实体                   │
│   0 个    │   0      │          │       0               │
└──────────┴──────────┴──────────┴──────────────────────┘
```

#### Tab 1：套件列表

- 卡片网格展示：suiteId / domain / project / 实体数 / 关系数 / 导入时间
- 选中 → 右上角"选择套件: xxx"，解锁其他 3 个 Tab
- "重新导入"按钮 → `POST /api/suites/import` → 重新解析 datasource（保留 annotations）

#### Tab 2：覆盖度（选中套件后显示）

```
┌──────────────┬──────────────┬──────────────┬──────────────┬──────────────┐
│ 叶子总数 200 │ 已覆盖   1%  │ 部分   0%   │ 缺口   0%    │ 未标注  99%  │
└──────────────┴──────────────┴──────────────┴──────────────┴──────────────┘
┌────────────────────────────────────────────────────────────────────┐
│  按层级聚合矩阵                                         │
│       │ 已覆盖 │ 部分 │ 缺口 │ 未标注 │ 覆盖%                      │
│  L1   │   0    │  0   │  0   │  13   │   0%                       │
│  L2   │   0    │  0   │  0   │  71   │   0%                       │
│  L3   │   1    │  0   │  0   │  192  │   0%                       │
│  叶子 │   1    │  0   │  0   │  199  │   0%                       │
└────────────────────────────────────────────────────────────────────┘
┌────────────────────────────────────────────────────────────────────┐
│  各 Domain 覆盖                                                     │
│  9.0 管理财务资源  ████████████████░░░░░  1 / 16  已覆盖             │
│  1.0 制定愿景战略  ░░░░░░░░░░░░░░░░░░░░░  0 / 8   未标注             │
│  ...                                                                │
└────────────────────────────────────────────────────────────────────┘
```

#### Tab 3：APQC 框架

- 树状展开/收起，带模糊搜索（支持后代匹配：父节点被搜索到时，子节点也可见）
- 每个节点显示：code、label、覆盖状态徽章（已覆盖/部分/缺口/未标注）、关联实体数
- 点击节点 → 右侧详情：完整路径（1.0 › 1.1 › 1.1.1）、定义、关联实体列表（可点击跳转到实体 Tab）

#### Tab 4：实体

- kind 下拉筛选 + keyword 搜索（匹配 name / rawId / domain）
- 300 条分页表格：序号 | 名称+ID | kind | APQC 编号 | 覆盖状态
- 点击行 → 右侧 Drawer 滑出（标注面板）

### Annotation Drawer

```
┌─────────────────────────────────┐
│ ✕  产品                          │
│    reference-example:AGG-PRODUCT │
├─────────────────────────────────┤
│ 实体信息                          │
│  产品实体描述...                  │
│  domain: 销售合同管理              │
│  source: m1-object-model.yaml    │
├─────────────────────────────────┤
│ APQC 编号                         │
│  [ 9.3.1      ]  ← 带模糊搜索     │
│  → 推导 ONT.B.9.3.1              │
├─────────────────────────────────┤
│ 覆盖状态                          │
│ [已覆盖] [部分] [缺口] [未标注]    │
├─────────────────────────────────┤
│ 备注                              │
│  [ 该实体属于账户对账流程     ]    │
├─────────────────────────────────┤
│              [ 保存 ]             │
└─────────────────────────────────┘
```

### 主题同步

iframe 加载后，`client.ts` 的 `injectThemeToIframe` 从父 Harness 读取 `--dsw-bg` / `--dsw-text-primary` / `--dsw-alias-brand-primary` 等 CSS 变量，注入到 iframe `<html>`。同时同步 `data-ds-theme` / `data-ds-dark-theme` 属性。iframe 内也做了 `prefers-color-scheme` fallback。

---

## 七、文件清单

```
src/
├── index.ts                      # cordis 入口，server + client 都从这里注册
├── server.ts                     # HTTP server · 路由分发 · HTML 渲染
├── server-utils.ts               # sendJson / sendHtml / readJsonBody / parseUrl
├── shared-types.ts               # 全部 interface/type 定义
├── datastore.ts                  # suite 持久化 + annotations IO + computeCoverage
├── ontology-parser.ts            # YAML → 实体/关系解析 + suite 发现
├── builtin-frameworks.ts         # 框架工具函数 + 编号推导
├── client.ts                     # cordis 插件客户端（sidebar 注入 + official panel 注册）
├── client/shared.ts              # discoverServer() + STYLES 常量
├── ui/                           # 前端源码（按 Tab 拆分，build-ui.mjs 组装为 dist/ui.html）
│   ├── layout.html               # 页面外壳（header / tabs / 抽屉 / toast + @include 标记）
│   ├── css/                      # base / suites / coverage / framework / ontology
│   ├── pages/                    # suites / coverage / framework / ontology 四个 Tab
│   └── scripts/                  # shared / suites / coverage / framework / ontology / main
├── frameworks/
│   └── apqc-pcf.ts               # APQC v7.4 框架数据（TS 常量）
├── datasource/                   # 原始数据（只读）
│   ├── APQC/
│   │   └── 业务流程分组_APQC_2022.07.23.xlsx
│   └── Ontology/
│       └── reference-example/
│           ├── manifest.json
│           ├── m1-object-model.yaml  ~ m7-report-model.yaml
│           └── 合同管理需求规格说明书-V9.md
└── datastorage/                  # 解析后缓存 + 标注层（可写）
    └── ontologies/
        └── reference-example/
            ├── meta.json          suiteId / domain / entityCount / importTime
            ├── entities.json       170 条
            ├── relations.json      331 条
            └── annotations.json    entityFrameMapping + coverageMarks
```

### reference-example 实际数据

| 指标 | 值 |
|------|----|
| Suite ID | `reference-example` |
| Domain | 销售合同执行管理 |
| Project | contract-management |
| 实体数 | 170 |
| 关系数 | 331 |
| 实体 kind | AGGREGATE_ROOT / ENTITY / DATA_DICTIONARY / BEHAVIOR / RULE / ACTOR / ROLE / PERMISSION / FLOW / ACTIVITY / REPORT / UI_MENU / UI_SCREEN (共 13 种) |
| APQC 框架 | 13 Domain / 71 L2 / 193 L3 / 200 叶子 |

---

## 八、构建与运行

```bash
# 开发模式（tsc watch + src/ui/** 变更自动重组装）
pnpm dev

# 构建
pnpm build        # tsc → dist/ + wrap-client → dist/client.js + build-ui 组装 → dist/ui.html

# 类型检查
pnpm typecheck    # tsc --noEmit

# 测试（预留，目前无测试文件）
pnpm test:run
```

### cordis integration

`cordis.patch.yml` 声明插件：

```yaml
- insert:
    - id: dsh-ontology
      name: dsh-ontology
```

插件注册后自动：
1. 启动 HTTP server（端口 17320~17329 自动重试）
2. 在 sidebar 注入 "Ontology" 按钮
3. 点击按钮 → cordis official panel 模式注册 iframe 面板（fallback 到 legacy DOM 注入）
4. 首次加载时异步 `importFromDatasource(false)` 解析 datasource 目录

---

## 九、已知局限与后续计划

| 阶段 | 内容 |
|------|------|
| **P0 · 当前 v1** | 5 层框架骨架、树状覆盖度、标注抽屉、单套件 reference-example 端到端跑通 |
| **P1 · 扩展 APQC 完整数据** | 当前 apqc-pcf.ts 只写了 13 L1 + 示例 L2/L3。官方 v7.4 约 1000+ L4/L5 节点，可从 Excel 批量导入（后端已预留 `frameworks/import` 接口） |
| **P2 · 多套件支持** | 支持 datasource 下放多个 `*/manifest.json` 套件目录，导入全部后套件列表展示多张卡片 |
| **P3 · 关系图谱可视化** | `GET /api/suites/{id}/graph` 已返回 D3 格式数据，前端可用 vis-network 渲染 force-directed 图 |
| **P4 · 批量标注 & 反向查询** | 批量给多个实体打同一个 APQC 编号；支持 ONT 编号 → APQC 节点反查 |
| **P5 · 版本化 annotations** | 每次保存带时间戳快照，支持 diff 历史变更 |
| **P6 · 图数据库迁移** | 当实体量超过 1 万时，从 JSON/SQLite 迁移到 Neo4j 或 SQLite FTS，保持 API 不变 |
| **P7 · APQC 覆盖度自动推导** | 基于实体名称/semantic embedding 推荐最匹配的 APQC 节点 |

### 已知 Bug（当前版本）

| 问题 | 影响 | 修复 |
|------|------|------|
| `ui.html` 曾被 PowerShell `Set-Content` 破坏 UTF-8 编码 | ~59 处中文乱码，12 处破坏 JS 语法导致白屏 | 用 Edit 工具逐条修复；**切记不要用 PowerShell Set-Content/Out-File 写中文文件** |
| fetch URL 最初硬编码 `http://127.0.0.1:17320` | discoverServer 返回动态端口时 fetch 404 | 改为同源相对路径 `'/api/...'`，iframe 内自动匹配端口 |

---

## 十、API 兼容性承诺

- 所有已公开路由保持稳定
- `CoverageMatrix` 类型新增 `leafTotal/leafCovered/...` 字段（向后兼容，旧消费者忽略即可）
- annotations.json 结构（`entityFrameMapping` + `coverageMarks`）为最终版本
- 框架编号模板 `{L1}.{L2}.{L3}.{L4}.{L5}` 固定不变

---

## 附录：Ontology 编号推导示例

```
APQC code       →  Ontology code
──────────────────────────────────
1.0             →  ONT.B.1.0        (Domain 级别)
1.3.1           →  ONT.B.1.3.1      (L2/L3)
9.3.1           →  ONT.B.9.3.1      (财务-执行-账户对账)
12.4.1.2        →  ONT.B.12.4.1.2   (完整 5 层)

反向: deriveApqcCode('ONT.B.9.3.1') → '9.3.1'
```